function Pizza(size, crust) {
    this.size = size;
    this.crust = crust;
    this.toppings = [];
  }
  
  function Location(name, estate) {
    this.name = name;
    this.estate = estate;
  }
  
  
  var sizePrice = {
    small: 1490,
    medium: 1990,
    large: 2490
  };

  var toppingPrice = {
    mozzarella: 550,
    cheddar: 490,
    jalapeno: 190,
    ham: 550,
    chicken: 990,
    tomato: 390
  };
  
  
  var crustPrice = {
    crispy: 490,
    traditional: 390,
    gluten: 690
  };
  
  function sizeCalcPrice(size) {
    if (size === "small") {
      return sizePrice.small * 1;
    } else if (size === "medium") {
      return sizePrice.medium * 1;
    } else {
      return sizePrice.large * 1;
    }
  }
  
  function crustCalcPrice(crust) {
    if (crust === "crispy") {
      return crustPrice.crispy * 1;
    } else if (crust === "stuffed") {
      return crustPrice.stuffed * 1;
    } else {
      return crustPrice.gluten * 1;
    }
  }
  
  function toppingsCalcPrice(toppings) {
    var totalToppingPrice = 0;
    for (var i = 0; i < toppings.length; i++) {
      if (toppings[i] === "mozzarella") {
        totalToppingPrice += toppingPrice.mozzarella;
      }
      if (toppings[i] === "cheddar") {
        totalToppingPrice += toppingPrice.cheddar;
      }
      if (toppings[i] === "jalapeno") {
        totalToppingPrice += toppingPrice.jalapeno;
      }
      if (toppings[i] === "ham") {
        totalToppingPrice += toppingPrice.ham;
      }
      if (toppings[i] === "chicken") {
        totalToppingPrice += toppingPrice.chicken;
      }
      if (toppings[i] === "tomato") {
        totalToppingPrice += toppingPrice.tomato;
      }
    }
    return totalToppingPrice;
  }
  

  
  
  
  function checkPepperoni(topping) {
    return topping === "pepperoni";
  }
  

  $("document").ready(function() {
    
    function getPizzaSize() {
      var size = $("#pizza-size").find(":selected").val();
      console.log("Selected size: ", size); 
      return size;
    }
    
    function getCrust() {
      var crust = $("#pizza-crust").find(":selected").val();
      console.log("Selected crust: ", crust); 
      return crust;
    }
    
    function getToppings() {
      var toppingList = [];
      $(".toppings :checked").each(function() {
        toppingList.push($(this).val());
      });
      console.log("Selected toppings: ", toppingList); 
      return toppingList;
    }
    
  
    
    $("form#myform").submit(function(event) {
      event.preventDefault();
      
      var pizzaSize = getPizzaSize();
      var crust = getCrust();
      var toppingList = getToppings();
      
      var newPizza = new Pizza(pizzaSize, crust);
      newPizza.toppings = toppingList;
    
      console.log(newPizza); 
      
      $("#cart").hide();
      $("#table").show();
      $(".checkout").show();
      
      var oneOrder = sizeCalcPrice(pizzaSize) +
               crustCalcPrice(crust) +
               toppingsCalcPrice(toppingList, pizzaSize);

      
               $("#items").append(
                "<tr>" +
                  "<td>" + newPizza.size + "</td>" +
                  "<td>" + newPizza.crust + "</td>" +
                  "<td>" + newPizza.toppings.join(", ") + "</td>" +
                  "<td>" + oneOrder + "</td>" +
                "</tr>"
              );
              

      
      console.log($("#items").html());
    });
    
    
    
    var totalQuantity = parseInt($("#quantity").val());
    function calcTotal() {
      var priceOnePizza =
        sizeCalcPrice(getPizzaSize()) +
        crustCalcPrice(getCrust()) +
        toppingsCalcPrice(getToppings());
      return priceOnePizza;
    }
    var pizzaList = [];
    
    $("#orderbtn").on("click", function() {
      totalQuantity += 1;
      $("#quantity").text(totalQuantity);
      pizzaList.push(calcTotal());
    });
  
    
    $("#gettotal").click(function() {
      var total = 0;
      pizzaList.forEach(function(pizza) {
        total += pizza;
      });
      $("#money").text(total);
    });
  
    
    $("#myModel").click(function() {
      var deliver = confirm(
        "Would you like us deliver your pizza to your doorstep? transport cost 500 tg."
      );
      if (deliver) {
        var place = prompt("Enter your location");
        $("#place").text(place);
        $("#success").show();
      } else {
        $("#no-delivery").show();
      }
      
      $("#pizza-size").val("");
      $("#pizza-crust").val("");
      $("#items").remove();
      $("#quantity").text(0);
    });
  });